package com.iudigital.rentacar.data;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.iudigital.rentacar.domain.Brand;


@Repository
public interface BrandRepository extends CrudRepository<Brand, Integer>{
	
	

}
