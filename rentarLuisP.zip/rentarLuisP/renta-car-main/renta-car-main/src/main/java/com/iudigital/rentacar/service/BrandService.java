package com.iudigital.rentacar.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iudigital.rentacar.data.BrandRepository;
import com.iudigital.rentacar.domain.Brand;

@Service
public class BrandService {

	@Autowired
	private BrandRepository brandRepository;

	public void createBrand(Brand brand) {
		brandRepository.save(brand);
	}

	public List<Brand> getBrands() {
		List<Brand> brands = (List<Brand>) brandRepository.findAll();
		return brands;
	}

	public Brand getBrandById(int idBrand) {

		// Optional<Brand> brand= brandRepository.findById(idBrand);
		// return brand.orElse(new Brand());

		Brand brand = brandRepository.findById(idBrand).orElse(new Brand());
		return brand;

	}

	public void editBrand(int idBrand, Brand brand) {

		Brand brandUpdate = brandRepository.findById(idBrand).orElse(null);
		if (brandUpdate != null) {
			brandUpdate.setFabricante(brand.getFabricante());
			brandUpdate.setImportacion(brand.getImportacion());
			brandUpdate.setPais(brand.getPais());
			brandUpdate.setFoto(brand.getFoto());
			
			brandRepository.save(brandUpdate);
		}
	}
		public void deleteBrand(int idBrand) {

			Brand brandDelete = brandRepository.findById(idBrand).orElse(null);
			if (brandDelete != null) {
				
				brandRepository.deleteById(idBrand);
				
			}

	}
	

}